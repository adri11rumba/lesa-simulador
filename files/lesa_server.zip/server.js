/* ============================================================
   LESA SIM · Servidor de sincronización
   ------------------------------------------------------------
   Mantiene el estado de la simulación y lo sincroniza entre
   el profesor y el/los alumno(s) por WebSocket.

   El servidor es la "fuente de verdad": corre el reloj y la
   física, recibe comandos del profesor y reenvía el estado a
   todos los conectados ~20 veces por segundo.

   Cómo arrancar (ver README):
     npm install
     node server.js
   ============================================================ */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;

/* ---------- Servidor HTTP: sirve el index.html (la app) ---------- */
const server = http.createServer((req, res) => {
  let file = req.url === '/' ? '/index.html' : req.url;
  file = file.split('?')[0];                       // quitar query string
  const full = path.join(__dirname, 'public', path.normalize(file).replace(/^(\.\.[/\\])+/, ''));
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); res.end('No encontrado'); return; }
    const ext = path.extname(full).toLowerCase();
    const types = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

/* ---------- Estado de la simulación (autoridad del servidor) ---------- */
const ARP = { lat: 40.951944, lon: -5.501944 };
const NM = 1852, KT = 0.514444;
const RWY = { hdg: 28, len: 2513, w: 45 };

function brgRng(b, nm){ const a=b*Math.PI/180, d=nm*NM; return { x:Math.sin(a)*d, y:-Math.cos(a)*d }; }
function rwyEnds(){ const dir=RWY.hdg*Math.PI/180, half=RWY.len/2;
  const dx=Math.sin(dir)*half, dy=-Math.cos(dir)*half;
  return { thr03:{x:-dx,y:-dy}, thr21:{x:dx,y:dy} }; }

const REF = {
  'N-1':brgRng(345,4.2), 'N':brgRng(338,7.0), 'E':brgRng(100,6.8),
  'E-1':brgRng(108,4.6), 'S':brgRng(178,6.8), 'W':brgRng(262,6.2)
};
const BBI_POS = brgRng(35,0.8);
function fromBBI(b,nm){ const a=b*Math.PI/180,d=nm*NM; return {x:BBI_POS.x+Math.sin(a)*d, y:BBI_POS.y-Math.cos(a)*d}; }
const APP_REF = {
  'BBI':BBI_POS,'VETAN':fromBBI(353,18),'ZMR':fromBBI(5,32),'ADORO':fromBBI(318,46),
  'VLD/NUB':fromBBI(28,50),'DSK':fromBBI(90,56),'RVO':fromBBI(235,62),'BARDI':fromBBI(210,46),
  'NVS':fromBBI(118,67),'MLN':fromBBI(170,75),'TLD':fromBBI(130,81),'CCS':fromBBI(200,100)
};
REF['BBI'] = BBI_POS;

const STATES = { PROG:'PROG',RODAJE:'RODAJE',ESPERA:'ESPERA',PISTA:'PISTA',AIRE:'AIRE',APROX:'APROX',FINAL:'FINAL' };

let state = {
  running:false, time:0, speed:1,
  schedule:[],          // vuelos programados
  aircraft:[],          // vuelos activos
  uid:1
};

/* ---------- Física (idéntica a la del cliente original) ---------- */
function targetSpeed(ac){
  switch(ac.state){
    case STATES.PROG:return 0; case STATES.RODAJE:return 15; case STATES.ESPERA:return 0;
    case STATES.PISTA:return ac.op==='DEP'?140:8; case STATES.AIRE:return 200;
    case STATES.APROX:return 180; case STATES.FINAL:return 130; default:return ac.spd;
  }
}
function turnToward(cur,want,maxd){ let d=((want-cur+540)%360)-180; if(Math.abs(d)<=maxd)return want; return (cur+Math.sign(d)*maxd+360)%360; }
function lookup(pt){ return REF[pt]||APP_REF[pt]; }

function spawn(f){
  const ends=rwyEnds();
  let ac={ id:state.uid++, cs:f.cs, type:f.type, op:f.op, orig:f.orig, dest:f.dest, route:f.route, lvl:f.lvl,
    x:0,y:0,hdg:RWY.hdg,spd:0,alt:2595, state:f.op==='DEP'?STATES.PROG:STATES.AIRE,
    target:null, cmdHist:[], tContact:null, tTakeoff:null, platform:'CIV' };
  if(f.op==='DEP'){
    const mil=(f.type[0]==='C'||f.type==='C295'||f.type==='C101'||f.dest==='LEAB');
    const dir=RWY.hdg*Math.PI/180, px=Math.cos(dir),py=Math.sin(dir),ax=Math.sin(dir),ay=-Math.cos(dir), gapPar=120;
    if(mil){ const gap=gapPar+260,along=260; ac.x=px*(gap+210)+ax*along; ac.y=py*(gap+210)+ay*along; }
    else   { const gap=gapPar+240,along=-420; ac.x=px*(gap+150)+ax*along; ac.y=py*(gap+150)+ay*along; }
    ac.hdg=RWY.hdg; ac.platform=mil?'MIL':'CIV';
  } else {
    const entry=APP_REF['DSK']; ac.x=entry.x; ac.y=entry.y; ac.alt=2595+5500; ac.spd=240;
    ac.hdg=(Math.atan2(-entry.x,entry.y)*180/Math.PI+360)%360; ac.target={mode:'point',pt:'BBI'};
  }
  state.aircraft.push(ac);
}

function step(dt){
  state.schedule.forEach(f=>{ if(!f.spawned && state.time>=f.time){ f.spawned=true; spawn(f); } });
  state.aircraft.forEach(ac=>{
    const tgt=targetSpeed(ac); const accel=(tgt>ac.spd?3:5)*dt;
    if(Math.abs(tgt-ac.spd)<accel*1.2) ac.spd=tgt; else ac.spd+=Math.sign(tgt-ac.spd)*accel;
    if(ac.target){
      let dest=null;
      if(ac.target.mode==='point') dest=lookup(ac.target.pt);
      else if(ac.target.mode==='xy') dest=ac.target;
      if(dest){
        const dx=dest.x-ac.x, dy=dest.y-ac.y, dist=Math.hypot(dx,dy);
        const want=(Math.atan2(dx,-dy)*180/Math.PI+360)%360;
        ac.hdg=turnToward(ac.hdg,want,90*dt);
        if(dist<300){
          if(ac.target.mode==='point'&&ac.target.pt==='BBI'&&ac.op==='ARR'){ ac.state=STATES.APROX; ac.target={mode:'point',pt:'E'}; }
          else ac.target=null;
        }
      }
    }
    const v=ac.spd*KT*dt;
    ac.x+=Math.sin(ac.hdg*Math.PI/180)*v; ac.y+=-Math.cos(ac.hdg*Math.PI/180)*v;
    if(ac.state===STATES.AIRE && ac.alt<2595+(+ac.lvl)*100) ac.alt+=12*dt;
    if(ac.state===STATES.FINAL) ac.alt=Math.max(2595,ac.alt-15*dt);
    if(ac.state===STATES.PISTA && ac.spd>110 && ac.op==='DEP'){ ac.state=STATES.AIRE; ac.tTakeoff=state.time; }
  });
  state.aircraft=state.aircraft.filter(ac=>{ const r=Math.hypot(ac.x,ac.y)/NM; return !(r>9 && ac.state===STATES.AIRE && ac.op==='DEP'); });
}

/* ---------- Comandos del profesor ---------- */
function depRwy(ac){return ac.platform==='MIL'?'21':'03';}
function depHdg(ac){return ac.platform==='MIL'?208:28;}
function holdPoint(ac){
  const dir=RWY.hdg*Math.PI/180, ax=Math.sin(dir),ay=-Math.cos(dir),px=Math.cos(dir),py=Math.sin(dir);
  const sgn=ac.platform==='MIL'?+1:-1;
  return { mode:'xy', x:ax*(RWY.len/2-90)*sgn+px*(RWY.w/2+8), y:ay*(RWY.len/2-90)*sgn+py*(RWY.w/2+8) };
}
function downwindPoint(){return brgRng((208+180+25)%360,3.0);}
function basePoint(){return brgRng((208+180)%360,2.5);}

function applyCommand(id, action, arg){
  const ac=state.aircraft.find(a=>a.id===id); if(!ac)return;
  const e=rwyEnds();
  switch(action){
    case 'taxi_hold': ac.state=STATES.RODAJE; ac.target=holdPoint(ac); break;
    case 'lineup': ac.state=STATES.PISTA; ac.spd=0; ac.target=null; ac.hdg=depHdg(ac); if(!ac.tContact)ac.tContact=state.time; break;
    case 'takeoff': ac.state=STATES.PISTA; ac.tTakeoff=state.time; break;
    case 'land': ac.state=STATES.FINAL; ac.target={mode:'xy',...e.thr21}; break;
    case 'downwind': ac.state=STATES.AIRE; ac.target=downwindPoint(); break;
    case 'base': ac.target=basePoint(); break;
    case 'final': ac.state=STATES.FINAL; ac.target={mode:'xy',...e.thr21}; break;
    case 'orbit': ac.target=null; break;
    case 'rp': if(ac.state===STATES.PROG)ac.state=STATES.AIRE; ac.target={mode:'point',pt:arg}; break;
    case 'toBBI': ac.target={mode:'point',pt:'BBI'}; break;
    case 'ils': ac.state=STATES.APROX; ac.target={mode:'point',pt:'E'}; break;
  }
  ac.cmdHist.push(action+(arg?' '+arg:''));
}

/* ---------- WebSocket: sincronización ---------- */
const wss = new WebSocketServer({ server });
const clients = new Set();

function broadcast(obj){ const msg=JSON.stringify(obj); for(const c of clients) if(c.readyState===1) c.send(msg); }
function snapshot(){ return { type:'state', running:state.running, time:state.time, speed:state.speed,
  schedule:state.schedule, aircraft:state.aircraft }; }

wss.on('connection', (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify(snapshot()));   // estado inicial al conectarse
  ws.on('message', (raw) => {
    let m; try{ m=JSON.parse(raw); }catch(e){ return; }
    switch(m.type){
      case 'setSchedule': state.schedule = m.schedule.map(f=>({...f, spawned:false})); break;
      case 'play':  if(state.schedule.length) state.running=true; break;
      case 'pause': state.running=false; break;
      case 'reset': state.running=false; state.time=0; state.aircraft=[]; state.uid=1;
                    state.schedule.forEach(f=>f.spawned=false); break;
      case 'speed': state.speed = m.speed; break;
      case 'command': applyCommand(m.id, m.action, m.arg); break;
      case 'ping': return;   // latido keepalive: no requiere difusión
    }
    broadcast(snapshot());                // tras cualquier cambio, sincroniza
  });
  ws.on('close', () => clients.delete(ws));
});

/* ---------- Bucle de simulación (servidor) ---------- */
let last = Date.now();
setInterval(() => {
  const now = Date.now(); let dt=(now-last)/1000; last=now;
  if(state.running){ dt*=state.speed; state.time+=dt; step(dt); }
}, 50);                                   // 20 Hz física

// difusión periódica del estado (aunque no haya comandos)
setInterval(() => broadcast(snapshot()), 100);   // 10 Hz red

server.listen(PORT, () => {
  console.log('============================================');
  console.log(' LESA SIM · servidor en marcha');
  console.log(' Local:    http://localhost:' + PORT);
  console.log(' En red:   http://<TU-IP-LOCAL>:' + PORT);
  console.log('============================================');
});
