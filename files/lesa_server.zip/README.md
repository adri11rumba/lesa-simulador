# LESA SIM · Simulador de control en red (profesor + alumno)

Esta carpeta contiene **todo** lo necesario para que el profesor y el alumno
trabajen cada uno en su ordenador, sincronizados en tiempo real.

```
lesa_server/
├── server.js          ← el servidor (la "fuente de verdad")
├── package.json       ← define la dependencia (ws)
├── public/
│   └── index.html     ← la aplicación (profesor y alumno usan la misma)
└── README.md          ← este archivo
```

---

## REQUISITO PREVIO: Node.js

Necesitas **Node.js** instalado en el ordenador que hará de servidor
(puede ser el del profesor). Descárgalo en https://nodejs.org (versión LTS).
Para comprobar que está instalado, abre una terminal (CMD/PowerShell en
Windows) y escribe:

```
node --version
```

Si muestra un número (p.ej. v20.x), ya lo tienes.

---

## PASO 1 — Instalar (solo la primera vez)

Abre una terminal **dentro de esta carpeta** (`lesa_server`) y ejecuta:

```
npm install
```

Esto descarga la única dependencia (`ws`, para WebSocket). Tarda unos segundos.

## PASO 2 — Arrancar el servidor

En la misma terminal:

```
node server.js
```

Verás algo así:

```
 LESA SIM · servidor en marcha
 Local:    http://localhost:3000
 En red:   http://<TU-IP-LOCAL>:3000
```

Deja esa terminal abierta mientras dure la sesión.

---

## CASO A — Misma red (clase, mismo WiFi)  ← lo más sencillo

1. En el **ordenador servidor**, averigua su IP local:
   - Windows: `ipconfig`  → busca "Dirección IPv4" (algo como 192.168.1.42)
   - Mac/Linux: `ifconfig` o `ip a`
2. El **profesor** abre en su navegador:  `http://localhost:3000`
   (o la IP, da igual, está en la misma máquina) y pulsa **PROFESOR**.
3. El **alumno**, en su ordenador, abre:  `http://192.168.1.42:3000`
   (poniendo la IP real del servidor) y pulsa **ALUMNO**.

Ya está. El reloj, los aviones y los comandos se sincronizan solos.
Arriba aparece el indicador **● EN RED** en verde cuando hay conexión.

---

## CASO B — Distinta red (cada uno en su casa)

Necesitas exponer el servidor a internet con un túnel. La forma fácil es
**ngrok** (gratis):

1. Descarga ngrok en https://ngrok.com/download y crea una cuenta gratuita.
2. Arranca el servidor normal (`node server.js`).
3. En **otra** terminal, ejecuta:

   ```
   ngrok http 3000
   ```

4. ngrok te dará una dirección pública, por ejemplo:
   `https://a1b2c3d4.ngrok-free.app`
5. **Los dos** (profesor y alumno) abren ESA dirección en su navegador,
   desde cualquier sitio. Cada uno elige su rol.

> La app detecta sola si va por http (local) o https (ngrok) y se conecta
> al WebSocket correcto. No hay que cambiar nada en el código.

---

## Uso durante la sesión

- El **profesor** programa los vuelos ("Programar vuelos"), pulsa **Iniciar**,
  selecciona aviones y les da comandos. Ve el radar (con separaciones) y las
  fichas. Puede cambiar a **Modo aproximación** para el mapa expandido.
- El **alumno** ve la torre y las fichas, y va notificando separaciones /
  controlando según lo que aparece.
- Todo lo que hace el profesor se refleja al instante en la pantalla del alumno.

## Problemas frecuentes

- **"○ SIN CONEXIÓN" en rojo**: el servidor no está arrancado, o la dirección/IP
  es incorrecta, o un firewall bloquea el puerto 3000. En misma red, asegúrate
  de que ambos están en el mismo WiFi y que el firewall de Windows permite Node.
- **El alumno no ve la IP**: comprueba que usaste la IP del servidor, no la suya.
- **Quiero otro puerto**: arranca con `PORT=8080 node server.js` (Mac/Linux) o
  `set PORT=8080 && node server.js` (Windows CMD).
