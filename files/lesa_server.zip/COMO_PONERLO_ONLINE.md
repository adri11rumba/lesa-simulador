# LESA SIM · Ponerlo ONLINE (sin instalar nada, sin terminal)

Objetivo: tener una dirección web pública (p.ej. `https://lesa-sim.onrender.com`)
que tú y tu compañero abrís desde cualquier ordenador. Cada uno elige Profesor o
Alumno y quedáis conectados en tiempo real.

Se hace en dos partes: (1) subir estos archivos a GitHub, (2) conectarlos a Render.
Todo por la web, con clics. Lo haces **una sola vez tú**. Tu compañero solo recibe
el enlace final.

> Necesitarás crear dos cuentas gratuitas: GitHub y Render. Usa el mismo correo en
> ambas para que sea más fácil conectarlas.

---

## PARTE 1 · Subir los archivos a GitHub

1. Entra en https://github.com y crea una cuenta gratis (botón "Sign up").
2. Una vez dentro, arriba a la derecha pulsa el **+** → **New repository**.
3. En "Repository name" escribe:  `lesa-sim`
4. Marca la opción **Public**.
5. Pulsa el botón verde **Create repository**.
6. En la página que aparece, busca el enlace que dice
   **"uploading an existing file"** (está en un párrafo de texto) y haz clic.
7. Ahora arrastra a la ventana del navegador **el contenido de la carpeta
   lesa_server** (NO la carpeta en sí, sino lo que hay dentro):
   - `server.js`
   - `package.json`
   - `render.yaml`
   - la carpeta `public` entera (con `index.html` dentro)
   - (el README puedes subirlo o no, da igual)

   > Truco: abre la carpeta `lesa_server`, selecciona todo con Ctrl+A, y arrastra.
   > GitHub mantiene la carpeta `public` y su contenido.
8. Abajo pulsa el botón verde **Commit changes**.

Ya tienes el código en GitHub. Deja esta pestaña abierta.

---

## PARTE 2 · Desplegar en Render

1. Entra en https://render.com y crea una cuenta gratis. Lo más cómodo es pulsar
   **"Sign up with GitHub"** (así quedan conectados automáticamente).
2. Una vez dentro, pulsa **New +** (arriba a la derecha) → **Web Service**.
3. Render te pedirá conectar tu GitHub y elegir un repositorio. Elige **lesa-sim**.
   - Si no aparece, pulsa "Configure account" / "Configure GitHub App" y dale
     permiso a Render para ver tus repositorios.
4. Render rellena casi todo solo (lo lee del archivo `render.yaml`). Comprueba que:
   - **Runtime / Language**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Instance Type / Plan**: **Free**
5. Pulsa **Create Web Service** (botón abajo).
6. Render empezará a construir. Verás un registro (log) corriendo. Espera 1-3 min,
   hasta que aparezca **"Live"** y un mensaje tipo `LESA SIM · servidor en marcha`.
7. Arriba de la página verás la URL pública, algo como:
   **`https://lesa-sim.onrender.com`**  ← ese es tu enlace.

---

## Usarlo

- Tú abres `https://lesa-sim.onrender.com` y eliges **PROFESOR**.
- Tu compañero abre la **misma** dirección (desde su casa, su móvil, donde sea) y
  elige **ALUMNO**.
- Arriba debe aparecer **● EN RED** en verde. Ya está: lo que hace el profesor se ve
  al instante en la pantalla del alumno.

Comparte ese enlace y no hace falta nada más. No se instala nada en ningún sitio.

---

## Cosas a saber del plan gratuito de Render

- **Se "duerme" tras 15 min sin uso.** La primera vez que entréis tras un rato,
  puede tardar ~30-60 segundos en despertar. Es normal; recarga la página si hace
  falta. Una vez despierto, va fluido.
- Si cambiáis algo del código en GitHub, Render lo vuelve a desplegar solo.

## Si algo falla

- **La página carga pero pone "○ SIN CONEXIÓN"**: espera a que Render ponga "Live";
  si lleva mucho, entra en el panel de Render y mira el log por si hay un error.
- **Render no encuentra el repositorio**: en Render, Settings → conecta/autoriza
  GitHub de nuevo.
- **Sale error en el build sobre "ws"**: asegúrate de haber subido `package.json`
  a GitHub (es el que le dice a Render qué instalar).
